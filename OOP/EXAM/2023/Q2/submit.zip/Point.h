#pragma once
#include <iostream>
#include "Line.h"

using std::cout;
using std::endl;

template <class T>
class Point{
public:
    T x;
    T y;
    Point(T _x,T _y) : x(_x), y(_y){}
    void move(T dx,T dy){
        x += dx;
        y += dy;
    }
    void show(){
        cout << '(' << x << ',' << y << ')' << endl;
    }
    bool check(const Line<T>& l){
        return (double(y) - double(l.k) * double(x) - double(l.b) < 1e-6 || double(l.k) * double(x) + double(l.b) - double(y) < 1e-6);
    }
};