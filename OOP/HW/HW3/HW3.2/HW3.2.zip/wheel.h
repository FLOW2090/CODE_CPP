#pragma once
#include <iostream>
using namespace std;

class Wheel {
	int number;
public:
	Wheel(int);
	int get_num();
};